#!/bin/bash
python3 start.py | lolcat
